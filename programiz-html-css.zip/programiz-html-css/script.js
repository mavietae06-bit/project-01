document.addEventListener("DOMContentLoaded", function () {

    /* =========================================
       GET HTML ELEMENTS
    ========================================= */

    const searchInput = document.getElementById("searchInput");
    const searchButton = document.getElementById("searchButton");
    const searchMessage = document.getElementById("searchMessage");
    const heroLogo = document.querySelector(".hero-logo");
    const header = document.querySelector("header");


    /* =========================================
       SEARCH FUNCTION
    ========================================= */

    function performSearch() {

        const searchText = searchInput.value.trim();

        /* Empty search */

        if (searchText === "") {

            searchMessage.textContent =
                "Please enter a restaurant, cuisine or dish.";

            searchInput.parentElement.classList.add("shake");

            setTimeout(function () {
                searchInput.parentElement.classList.remove("shake");
            }, 500);

            return;
        }


        /* Successful search */

        searchMessage.textContent =
            'Searching for "' + searchText + '"...';

        searchButton.textContent = "Searching...";

        searchButton.disabled = true;


        /* Simulate search */

        setTimeout(function () {

            searchMessage.textContent =
                'Results for "' + searchText + '" will appear here.';

            searchButton.textContent = "Search";

            searchButton.disabled = false;

        }, 1200);
    }


    /* =========================================
       SEARCH BUTTON CLICK
    ========================================= */

    searchButton.addEventListener("click", function () {
        performSearch();
    });


    /* =========================================
       ENTER KEY SEARCH
    ========================================= */

    searchInput.addEventListener("keydown", function (event) {

        if (event.key === "Enter") {
            performSearch();
        }

    });


    /* =========================================
       CLEAR MESSAGE WHEN USER TYPES
    ========================================= */

    searchInput.addEventListener("input", function () {

        if (searchInput.value.trim() !== "") {
            searchMessage.textContent = "";
        }

    });


    /* =========================================
       LOGO CLICK ANIMATION
    ========================================= */

    heroLogo.addEventListener("click", function () {

        heroLogo.style.transform = "scale(0.85)";

        setTimeout(function () {
            heroLogo.style.transform = "";
        }, 200);

    });


    /* =========================================
       NAVIGATION HOVER
    ========================================= */

    const navLinks =
        document.querySelectorAll("nav ul li a");

    navLinks.forEach(function (link) {

        link.addEventListener("mouseenter", function () {
            link.style.transform = "translateY(-3px)";
        });

        link.addEventListener("mouseleave", function () {
            link.style.transform = "translateY(0)";
        });

    });


    /* =========================================
       HEADER SCROLL EFFECT
    ========================================= */

    window.addEventListener("scroll", function () {

        if (window.scrollY > 50) {

            header.style.boxShadow =
                "0 6px 25px rgba(0, 0, 0, 0.35)";

        } else {

            header.style.boxShadow =
                "0 4px 15px rgba(0, 0, 0, 0.2)";
        }

    });


    /* =========================================
       PAGE LOAD MESSAGE
    ========================================= */

    console.log("Zomato website loaded successfully.");

});
